(async () => {
    var note = api.getActiveContextNote()
    var frame = api.$container.find(".my-iframe")
    var hint = api.$container.find(".my-hint")
    //console.log(note.type, frame, hint)
    //console.log('note', note)
    //console.log('api.$container', api.$container)
    //window.trilium_api = api;
    //console.log(await api.getNote(api.getActiveContextNote().children[0]));
    //==Import SingleFile.html as child of simpleSingleFileRenderer so there only one children below simpleSingleFileRenderer note
    if (note.type === "render" && frame.length === 1) {
        var children_notes_ids = api.getActiveContextNote().children;
        console.log(children_notes_ids.length);
        if(children_notes_ids.length >= 1){
            var singlefile_note = await api.getNote(api.getActiveContextNote().children[0]); 
            var singlefile_note_content = await singlefile_note.getContent();
            frame.attr("srcdoc", singlefile_note_content);
        } else {
            frame.hide()
             hint.text("Please Import the-SingleFile-any-name.html as second note of this Render notes ")
        }
        /*var webSrc = note.getAttributeValue("label", "webSrc")
        console.log(webSrc)
        if (webSrc != null) {
            frame.attr("src", webSrc)
        } else {
            frame.hide()
            hint.text("To load a webpage, set webSrc label to a URL")
        }*/
    } else {
        hint.text("Cannot find the iframe element")
    }
})();